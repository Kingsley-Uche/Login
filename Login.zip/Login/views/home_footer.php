
<div class="row">
    <div class='col-sm-12'>
    <script src="./assets/js/js/jquery.js" type="text/javascript"></script>
        <script src="./assets/js/js/popper.min.js" ></script>
        <script src="./assets/js/js/popper.min.js.map" ></script>
        
        <script src="./assets/js/js/jquery.js"></script>

  <script src="./assets/js/js/bootstrap.min.js" type="text/javascript" charset="utf-8" ></script>

    </div>

</div>
</div>
</body>
</html>
