<div class='box'>
    <div class="box-body mt-3">
        <div class='row'>
            <div class=''>
            <div class="col-sm-3">

            </div>              
                
<div class="col-sm-6">
    

</div>


            <div class="col-sm-3">

            </div>
            </div>
        </div>
        
<div class='row'>
    <div class="col-sm-3">

    </div>
    <div class="col-sm-6">
    
          <div class="card">
              <div class="card-header">
                  <h4 class="card-title">Assign Courses</h4>
              </div>
              <div class="card-block">
                  <div class="card-body">
                      <fieldset class="form-group">
                      <label for="Enter Course Name" class='sr-only'>Select Subject</label>
                          <select name="Subjects" id="" class='select2 form-control'>
                              <option value="">Select Subject</option>
                          </select>
                      </fieldset>
                  </div>
              </div>
              <div class="card-block">
                  <div class="card-body">
                  <fieldset class="form-group">
                          <label for="Enter Course Name" class='sr-only'>Course Name</label>
                          <input type="text" name="course_name" id="course_name" placeholder="Course name" class="form-control">
                      </fieldset>
                  </div>
              </div>
              <div class="card-block">
                  <div class="card-body">
                      <button class="btn btn-success">Assign</button>
                  </div>
              </div>
          </div>


          <div class="card">
              <div class="card-header">
                  <h4 class="card-title">Create Subject</h4>
              </div>
              <div class="card-block">
                  <div class="card-body">
                      <fieldset class="form-group">
                      <label for="Enter Course Name" class='sr-only'>Subject name</label>
                         <input type="text" name="subject" id=""placeholder='subject_name'>
                      </fieldset>
                  </div>
              </div>
              <div class="card-block">
                  <div class="card-body">
                  <fieldset class="form-group">
                          <label for="Enter Course Name" class='sr-only'>Course Name</label>
                          <input type="text" name="course_name" id="course_name" placeholder="Course name" class="form-control">
                      </fieldset>
                  </div>
              </div>
              <div class="card-block">
                  <div class="card-body">
                      <button class="btn btn-success">Save</button>
                  </div>
              </div>
          </div>
      

    </div>
    <div class="col-sm-3">

</div>
</div>

    </div>
   </div>